export  class Student
{
constructor(public Id:number,public Name?:string,public Age?:number){}
}