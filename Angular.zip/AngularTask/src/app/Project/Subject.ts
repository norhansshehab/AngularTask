export  class Subject
{
constructor(public Id:number,public Name?:string){}
}